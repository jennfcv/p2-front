<template>
  <div class="flex flex-col w-80 h-96 bg-white rounded-xl border shadow">
    <header class="bg-blue-600 text-white text-center py-2 rounded-t-xl">
      Chat Asistencia
    </header>

    <div class="flex-1 overflow-y-auto p-3 space-y-2 bg-gray-50 text-sm">
      <p
        v-for="m in messages"
        :key="m.id"
        :class="m.role === 'user' ? 'text-blue-700' : 'text-green-700'"
      >
        <b>{{ m.role === 'user' ? 'Yo' : 'Asistente' }}:</b> {{ m.content }}
      </p>
      <div ref="endRef"></div>
    </div>

    <form @submit.prevent="handleSend" class="flex border-t">
      <textarea
        rows="1"
        v-model="text"
        placeholder="Escribe y presiona Enter…"
        class="flex-1 resize-none p-2 text-sm outline-none"
        @keydown.enter.prevent.exact="handleSend"
      ></textarea>
      <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4">
        Enviar
      </button>
    </form>

    <div class="flex">
      <button @click="handleExportPDF" class="flex-1 p-2 bg-red-600 text-white text-center">
        PDF
      </button>
      <button
        @click="handleDownloadFlutter"
        class="flex-1 p-2 bg-green-600 text-white text-center rounded-br-xl"
      >
        Flutter ZIP
      </button>
    </div>

    <label class="mt-2 self-start ml-3 px-3 py-1 cursor-pointer bg-purple-600 text-white rounded">
      📷 Imagen
      <input type="file" accept="image/*" class="hidden" @change="handleImage" />
    </label>
  </div>
</template>

<script setup>
import { ref, nextTick } from 'vue'
import axios from 'axios'
import { jsPDF } from 'jspdf'
import JSZip from 'jszip'
import { saveAs } from 'file-saver'

const MODEL = 'gemini-pro'
const API_KEY = 'AIzaSyAK07dvmcGs2-YApiRWwn5Vg7MjT6E5nF8'
const CHAT_URL = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent?key=${API_KEY}`

const text = ref('')
const messages = ref([])
const endRef = ref(null)
const isLoading = ref(false)

const scrollToEnd = () => nextTick(() => endRef.value?.scrollIntoView({ behavior: 'smooth' }))

const handleSend = async () => {
  if (!text.value.trim() || isLoading.value) return
  
  const userMsg = { id: crypto.randomUUID(), role: 'user', content: text.value }
  messages.value.push(userMsg)
  const currentText = text.value
  text.value = ''
  isLoading.value = true
  scrollToEnd()

  try {
    const { data } = await axios.post(
      CHAT_URL,
      {
        contents: [{
          parts: [{
            text: currentText
          }]
        }]
      },
      { headers: { 'Content-Type': 'application/json' } }
    )

    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || '[No se recibió respuesta]'
    messages.value.push({ 
      id: crypto.randomUUID(), 
      role: 'assistant', 
      content: reply 
    })
  } catch (err) {
    console.error('Error con Gemini:', err)
    messages.value.push({ 
      id: crypto.randomUUID(), 
      role: 'assistant', 
      content: '❌ Error al conectar con Gemini. Por favor intenta nuevamente.' 
    })
  } finally {
    isLoading.value = false
    scrollToEnd()
  }
}

const fileToBase64 = file => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.onload = () => resolve(reader.result)
    reader.onerror = reject
    reader.readAsDataURL(file)
  })
}

const handleImage = async (e) => {
  const file = e.target.files[0]
  if (!file) return
  e.target.value = ''
  
  isLoading.value = true
  messages.value.push({ 
    id: crypto.randomUUID(), 
    role: 'user', 
    content: '[Imagen adjunta]' 
  })
  scrollToEnd()

  try {
    const b64 = await fileToBase64(file)
    const base64Data = b64.split(',')[1]

    const { data } = await axios.post(
      CHAT_URL,
      { 
        contents: [{
          parts: [
            { text: 'Describe esta imagen en detalle:' },
            {
              inlineData: {
                mimeType: file.type,
                data: base64Data
              }
            }
          ]
        }]
      },
      { headers: { 'Content-Type': 'application/json' } }
    )

    const reply = data.candidates?.[0]?.content?.parts?.[0]?.text || '[No se pudo analizar la imagen]'
    messages.value.push({ 
      id: crypto.randomUUID(), 
      role: 'assistant', 
      content: reply 
    })
  } catch (err) {
    console.error('Error con imagen:', err)
    messages.value.push({ 
      id: crypto.randomUUID(), 
      role: 'assistant', 
      content: '❌ Error al procesar la imagen. Intenta con otra.' 
    })
  } finally {
    isLoading.value = false
    scrollToEnd()
  }
}

const handleExportPDF = () => {
  const doc = new jsPDF({ unit: 'pt', format: 'a4' })
  let y = 40
  
  doc.setFontSize(14).text('Historial de Conversación', 40, 30)
  doc.setFontSize(11)
  
  messages.value.forEach((m) => {
    const role = m.role === 'user' ? 'Yo' : 'Asistente'
    const content = `${role}: ${m.content}`
    const lines = doc.splitTextToSize(content, 500)
    
    doc.setTextColor(m.role === 'user' ? '#1d4ed8' : '#15803d') // Azul/Verde
    doc.text(lines, 40, y)
    y += lines.length * 15
    
    if (y > 770) {
      doc.addPage()
      y = 40
    }
  })
  
  doc.save('chat_conversacion.pdf')
}

const toNullSafeLogin = (code) => {
  return code
    .replace(/String _username, _password;/g, "String _username = ''; String _password = '';")
    .replace(/value\.isEmpty/g, 'value == null || value.isEmpty')
    .replace(/onSaved: \(value\) => _username = value,/g, 'onSaved: (value) => _username = value!.trim(),')
    .replace(/onSaved: \(value\) => _password = value,/g, 'onSaved: (value) => _password = value!.trim(),')
    .replace(/_formKey\.currentState\.validate\(\)/g, '_formKey.currentState!.validate()')
    .replace(/_formKey\.currentState\.save\(\)/g, '_formKey.currentState!.save()')
}

const handleDownloadFlutter = async () => {
  const assistantMessages = messages.value
    .filter(m => m.role === 'assistant')
    .map(m => m.content)
    .join('\n')

  const regex = /```dart([\s\S]*?)```/g
  const snippets = []
  let match
  
  while ((match = regex.exec(assistantMessages))) {
    snippets.push(match[1].trim())
  }

  if (!snippets.length) {
    alert('No se encontró código Dart en la conversación')
    return
  }

  try {
    const zip = new JSZip()
    const root = zip.folder('flutter_app')
    
    // Archivo pubspec.yaml
    root.file('pubspec.yaml', `name: flutter_app
version: 1.0.0+1
description: Aplicación generada desde chat

environment:
  sdk: ">=2.17.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  cupertino_icons: ^1.0.2

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^2.0.0

flutter:
  uses-material-design: true`)

    // Carpeta lib
    const lib = root.folder('lib')
    
    // Procesar snippets
    let mainCode = snippets[0]
    
    // Ajustar imports si hay múltiples archivos
    if (snippets.length > 1) {
      mainCode = mainCode.replace(/import 'package:[^']+login_screen[^']+';/, "import 'login_screen.dart';")
      
      if (!/runApp\(const/.test(mainCode) && /runApp/.test(mainCode)) {
        mainCode = mainCode.replace(/runApp\(/, 'runApp(const ')
      }
    }

    lib.file('main.dart', mainCode)
    
    // Agregar otros snippets como archivos separados
    for (let i = 1; i < snippets.length; i++) {
      const fileName = i === 1 ? 'login_screen.dart' : `screen_${i}.dart`
      const content = i === 1 ? toNullSafeLogin(snippets[i]) : snippets[i]
      lib.file(fileName, content)
    }

    // Generar y descargar ZIP
    const content = await zip.generateAsync({ type: 'blob' })
    saveAs(content, 'flutter_app.zip')
    
  } catch (err) {
    console.error('Error al generar ZIP:', err)
    alert('Error al generar el archivo Flutter ZIP')
  }
}
</script>